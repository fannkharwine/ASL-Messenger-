import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const httpServer = createServer(app);

// Enable CORS
app.use(cors());
app.use(express.json());

// Serve static frontend files
app.use(express.static(__dirname));

// Socket.io initialization
const io = new Server(httpServer, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

/**
 * Zero-Knowledge In-Memory Temporary Relay Buffer
 * Map<userId, Array<EncryptedMessage>>
 * Messages are stored ONLY until delivered to the recipient, then purged immediately.
 */
const pendingMessages = new Map();

/**
 * Connected Sockets Map
 * Map<userId, { socketId, publicKey, displayName, avatar, lastSeen }>
 */
const connectedUsers = new Map();
const socketToUser = new Map();

io.on('connection', (socket) => {
  console.log(`[ASL Relay] Client connected: ${socket.id}`);

  // User Registers with Public Identity Key
  socket.on('register_user', ({ userId, displayName, publicKey, avatar }) => {
    if (!userId || !publicKey) {
      socket.emit('error_response', { message: 'userId and publicKey are required' });
      return;
    }

    const userData = {
      userId,
      displayName: displayName || userId,
      publicKey,
      avatar: avatar || 'shield-red',
      socketId: socket.id,
      online: true,
      lastSeen: new Date().toISOString()
    };

    connectedUsers.set(userId, userData);
    socketToUser.set(socket.id, userId);

    socket.emit('register_success', {
      userId,
      status: 'registered',
      serverTime: new Date().toISOString()
    });

    // Broadcast user presence update to all connected clients
    io.emit('user_presence', {
      userId,
      displayName: userData.displayName,
      publicKey: userData.publicKey,
      avatar: userData.avatar,
      online: true
    });

    // Deliver any temporary pending queued messages
    if (pendingMessages.has(userId)) {
      const queued = pendingMessages.get(userId);
      console.log(`[ASL Relay] Delivering ${queued.length} queued encrypted message(s) to ${userId}`);
      queued.forEach((msg) => {
        socket.emit('encrypted_message', msg);
      });
      // Zero-Knowledge Purge immediately after sending
      pendingMessages.delete(userId);
    }
  });

  // Query User Directory / Public Key Lookup
  socket.on('lookup_user', ({ targetUserId }) => {
    const user = connectedUsers.get(targetUserId);
    if (user) {
      socket.emit('user_info', {
        userId: user.userId,
        displayName: user.displayName,
        publicKey: user.publicKey,
        avatar: user.avatar,
        online: user.online,
        lastSeen: user.lastSeen
      });
    } else {
      socket.emit('user_not_found', { targetUserId });
    }
  });

  // Get directory of active users
  socket.on('get_active_users', () => {
    const usersList = [];
    for (const [uid, udata] of connectedUsers.entries()) {
      usersList.push({
        userId: udata.userId,
        displayName: udata.displayName,
        publicKey: udata.publicKey,
        avatar: udata.avatar,
        online: udata.online,
        lastSeen: udata.lastSeen
      });
    }
    socket.emit('active_users_list', { users: usersList });
  });

  // E2EE Encrypted Message Routing
  socket.on('send_encrypted_message', (payload) => {
    const { recipientId, senderId, iv, cipherText, mac, timestamp, messageId, replyTo } = payload;

    if (!recipientId || !cipherText || !iv) {
      socket.emit('error_response', { message: 'Invalid encrypted payload format' });
      return;
    }

    const encryptedPacket = {
      messageId: messageId || `msg_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
      senderId,
      recipientId,
      iv,
      cipherText,
      mac,
      timestamp: timestamp || new Date().toISOString(),
      replyTo: replyTo || null
    };

    const recipient = connectedUsers.get(recipientId);

    if (recipient && recipient.online && recipient.socketId) {
      // Direct relay to online socket
      io.to(recipient.socketId).emit('encrypted_message', encryptedPacket);

      // Send delivery receipt to sender
      socket.emit('message_status', {
        messageId: encryptedPacket.messageId,
        recipientId,
        status: 'delivered',
        timestamp: new Date().toISOString()
      });
    } else {
      // Store in temporary RAM queue until recipient connects
      if (!pendingMessages.has(recipientId)) {
        pendingMessages.set(recipientId, []);
      }
      const queue = pendingMessages.get(recipientId);
      // Enforce max RAM queue limit per user (e.g. 50 items)
      if (queue.length >= 50) {
        queue.shift(); // Evict oldest
      }
      queue.push(encryptedPacket);

      // Confirm queued status to sender
      socket.emit('message_status', {
        messageId: encryptedPacket.messageId,
        recipientId,
        status: 'queued',
        timestamp: new Date().toISOString()
      });
    }
  });

  // Typing Indicator Relay
  socket.on('typing_indicator', ({ recipientId, isTyping }) => {
    const senderId = socketToUser.get(socket.id);
    if (!senderId || !recipientId) return;

    const recipient = connectedUsers.get(recipientId);
    if (recipient && recipient.online && recipient.socketId) {
      io.to(recipient.socketId).emit('user_typing', {
        senderId,
        isTyping
      });
    }
  });

  // Read Receipt Relay
  socket.on('mark_as_read', ({ senderId, messageId }) => {
    const readerId = socketToUser.get(socket.id);
    if (!readerId || !senderId) return;

    const sender = connectedUsers.get(senderId);
    if (sender && sender.online && sender.socketId) {
      io.to(sender.socketId).emit('message_read_receipt', {
        messageId,
        readerId,
        timestamp: new Date().toISOString()
      });
    }
  });

  // Disconnect handling
  socket.on('disconnect', () => {
    const userId = socketToUser.get(socket.id);
    if (userId) {
      socketToUser.delete(socket.id);
      const user = connectedUsers.get(userId);
      if (user) {
        user.online = false;
        user.lastSeen = new Date().toISOString();

        io.emit('user_presence', {
          userId,
          displayName: user.displayName,
          publicKey: user.publicKey,
          avatar: user.avatar,
          online: false,
          lastSeen: user.lastSeen
        });
      }
    }
    console.log(`[ASL Relay] Client disconnected: ${socket.id}`);
  });
});

// Health check and Zero-Knowledge status
app.get('/api/health', (req, res) => {
  let pendingCount = 0;
  for (const queue of pendingMessages.values()) {
    pendingCount += queue.length;
  }

  res.json({
    status: 'healthy',
    app: 'ASL Messenger Zero-Knowledge Relay',
    activeConnections: connectedUsers.size,
    pendingQueuedMessagesRAM: pendingCount,
    persistentStorage: 'NONE (Zero-Knowledge Verified)',
    serverTime: new Date().toISOString()
  });
});

// Fallback to index.html for single-page app
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

const PORT = process.env.PORT || 3000;
httpServer.listen(PORT, () => {
  console.log(`====================================================`);
  console.log(`  ASL Messenger Server active on port ${PORT}`);
  console.log(`  Zero-Knowledge Encrypted Message Router Running`);
  console.log(`====================================================`);
});
