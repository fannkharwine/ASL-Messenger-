import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js';
import {
  getAuth,
  signInWithPopup,
  GoogleAuthProvider,
  onAuthStateChanged,
  signOut
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js';

let firebaseConfig = null;
try {
  const response = await fetch('/firebase-applet-config.json');
  firebaseConfig = await response.json();
} catch (e) {
  console.error('Failed to load firebase-applet-config.json', e);
}

let app = null;
let auth = null;
let provider = null;
let cachedAccessToken = null;
let isSigningIn = false;
let currentUser = null;

if (firebaseConfig) {
  app = initializeApp(firebaseConfig);
  auth = getAuth(app);
  provider = new GoogleAuthProvider();

  // Request required Workspace scopes
  provider.addScope('https://www.googleapis.com/auth/drive');
  provider.addScope('https://www.googleapis.com/auth/drive.file');
  provider.addScope('https://www.googleapis.com/auth/drive.readonly');
  provider.addScope('https://www.googleapis.com/auth/spreadsheets');
  provider.addScope('https://www.googleapis.com/auth/spreadsheets.readonly');
}

export function initWorkspaceAuth(onAuthChange) {
  if (!auth) return;
  onAuthStateChanged(auth, (user) => {
    currentUser = user;
    if (!user) {
      cachedAccessToken = null;
    }
    if (onAuthChange) onAuthChange(user, cachedAccessToken);
  });
}

export async function signInWithGoogle() {
  if (!auth || !provider) throw new Error('Firebase Auth not initialized');
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('Failed to obtain Google access token');
    }
    cachedAccessToken = credential.accessToken;
    currentUser = result.user;
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error) {
    console.error('Google Sign In Error:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
}

export async function googleSignOut() {
  if (!auth) return;
  await signOut(auth);
  cachedAccessToken = null;
  currentUser = null;
}

export function getAccessToken() {
  return cachedAccessToken;
}

export function getCurrentUser() {
  return currentUser;
}

// ==========================================
// GOOGLE DRIVE API SERVICES
// ==========================================

export async function fetchDriveFiles(searchQuery = '', mimeTypeFilter = '') {
  const token = getAccessToken();
  if (!token) throw new Error('Authentication required');

  let query = "trashed = false";
  if (mimeTypeFilter) {
    query += ` and mimeType = '${mimeTypeFilter}'`;
  }
  if (searchQuery) {
    const escaped = searchQuery.replace(/'/g, "\\'");
    query += ` and name contains '${escaped}'`;
  }

  const url = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(query)}&fields=files(id,name,mimeType,webViewLink,iconLink,thumbnailLink,createdTime,size,modifiedTime)&pageSize=40&orderBy=modifiedTime%20desc`;
  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${token}` }
  });

  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.error?.message || `Drive API error: ${res.status}`);
  }

  const data = await res.json();
  return data.files || [];
}

export async function createDriveTextFile(filename, textContent, folderId = null) {
  const token = getAccessToken();
  if (!token) throw new Error('Authentication required');

  const metadata = {
    name: filename,
    mimeType: 'text/plain'
  };
  if (folderId) {
    metadata.parents = [folderId];
  }

  const boundary = '-------314159265358979323846';
  const delimiter = "\r\n--" + boundary + "\r\n";
  const close_delim = "\r\n--" + boundary + "--";

  const body =
    delimiter +
    'Content-Type: application/json\r\n\r\n' +
    JSON.stringify(metadata) +
    delimiter +
    'Content-Type: text/plain\r\n\r\n' +
    textContent +
    close_delim;

  const res = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': `multipart/related; boundary=${boundary}`
    },
    body: body
  });

  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.error?.message || `Failed to create file: ${res.status}`);
  }

  return await res.json();
}

// ==========================================
// GOOGLE SHEETS API SERVICES
// ==========================================

export async function fetchSpreadsheetsList() {
  return await fetchDriveFiles('', 'application/vnd.google-apps.spreadsheet');
}

export async function createNewSpreadsheet(title) {
  const token = getAccessToken();
  if (!token) throw new Error('Authentication required');

  const res = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      properties: {
        title: title || 'ASL Messenger Chat Audit Log'
      },
      sheets: [
        {
          properties: {
            title: 'Chat Log'
          }
        }
      ]
    })
  });

  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.error?.message || `Failed to create spreadsheet: ${res.status}`);
  }

  return await res.json();
}

export async function getSpreadsheetDetails(spreadsheetId) {
  const token = getAccessToken();
  if (!token) throw new Error('Authentication required');

  const url = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}?includeGridData=true`;
  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${token}` }
  });

  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.error?.message || `Failed to fetch spreadsheet details: ${res.status}`);
  }

  return await res.json();
}

export async function appendSpreadsheetRows(spreadsheetId, range, rowsValues) {
  const token = getAccessToken();
  if (!token) throw new Error('Authentication required');

  const url = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}:append?valueInputOption=USER_ENTERED`;
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      values: rowsValues
    })
  });

  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.error?.message || `Failed to append rows: ${res.status}`);
  }

  return await res.json();
}
