# ASL Messenger - VPS Deployment & Self-Hosting Guide

This guide provides step-by-step terminal commands to host and run your own zero-knowledge ASL Messenger server on an Ubuntu Linux VPS.

---

## Step 1: Connect to your Ubuntu VPS & Update Packages

```bash
# SSH into your VPS
ssh root@YOUR_VPS_IP

# Update system packages
sudo apt update && sudo apt upgrade -y
```

---

## Step 2: Install Docker, Docker Compose, and Nginx

```bash
# Install Docker and Nginx
sudo apt install -y docker.io docker-compose nginx certbot python3-certbot-nginx git curl

# Start and enable Docker
sudo systemctl enable --now docker
sudo systemctl enable --now nginx
```

---

## Step 3: Clone/Upload ASL Messenger Project

```bash
# Create application directory
mkdir -p /var/www/asl-messenger
cd /var/www/asl-messenger

# Upload or copy your files (server.js, package.json, Dockerfile, docker-compose.yml, index.html, nginx.conf)
# Or create them directly in this directory.
```

---

## Step 4: Configure Nginx & SSL Certificate (Let's Encrypt)

```bash
# Copy nginx configuration
sudo cp nginx.conf /etc/nginx/sites-available/asl-messenger

# Edit your domain name in the config
sudo nano /etc/nginx/sites-available/asl-messenger
# Replace 'yourdomain.com' with your actual domain name!

# Enable site and test Nginx syntax
sudo ln -s /etc/nginx/sites-available/asl-messenger /etc/nginx/sites-enabled/
sudo nginx -t

# Obtain Free Let's Encrypt SSL Certificate
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com

# Reload Nginx
sudo systemctl reload nginx
```

---

## Step 5: Build and Run ASL Messenger Server via Docker

```bash
# Build and start container in detached background mode
docker-compose up -d --build

# Verify container is running
docker-compose ps

# Check live zero-knowledge relay logs
docker-compose logs -f
```

---

## Step 6: Verify Zero-Knowledge Relay Status

Open your browser or run:

```bash
curl https://yourdomain.com/api/health
```

Expected Response:
```json
{
  "status": "healthy",
  "app": "ASL Messenger Zero-Knowledge Relay",
  "activeConnections": 1,
  "pendingQueuedMessagesRAM": 0,
  "persistentStorage": "NONE (Zero-Knowledge Verified)"
}
```

Congratulations! Your self-hosted ASL Messenger server is running under your 100% full control!
